import pandas as pd

class CustomerTransactionProcessor:
    def load_customers(self, filepath: str) -> pd.DataFrame:
        return 

    def load_transactions(self, filepath: str) -> pd.DataFrame:
       pass
    def clean_transaction_data(self, df: pd.DataFrame) -> pd.DataFrame:
       
       pass

    def merge_data(self, transactions: pd.DataFrame, customers: pd.DataFrame) -> pd.DataFrame:
        pass

    def calculate_total_by_membership(self, merged_df: pd.DataFrame) -> pd.DataFrame:
        pass
